<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\users;

class search extends Controller
{
    //
    public function search(Request $request){
    	if($request["id"] == "" && $request["email"] == "" && $request["class"] == ""){
    		$resultsets = users::all();
    	}
    	else{ //find($request["id"])
    		if($request["id"] == "" && $request["email"] == ""){
    			$resultsets = users::where('class','like','%'.$request["class"].'%')->get();
    		}
    		elseif($request["id"] == "" && $request["class"] == ""){
    			$resultsets = users::where('email','like','%'.$request["email"].'%')->get();
    		}
    		elseif($request["class"] == "" && $request["email"] == ""){
    			$resultsets = users::where('id','like',$request["id"])->get();
    		}
    		elseif($request["id"] == ""){
    			$resultsets = users::where('email','like','%'.$request["email"].'%')->where('class','like','%'.$request["class"].'%')->get();
    		}
    		elseif($request["email"] == ""){
    			$resultsets = users::where('id','like',$request["id"])->where('email','like','%'.$request["email"].'%')->get();
    		}
    		elseif($request["class"] == ""){
    			$resultsets = users::where('id','like',$request["id"])->where('class','like','%'.$request["class"].'%')->get();
    		}
    		else{
    			$resultsets = users::where('id','like',$request["id"])->where('email','like','%'.$request["email"].'%')->where('class','like','%'.$request["class"].'%')->get();
    		}
    	}
    	
     	return view('searchresult', compact(['resultsets']));
    }
}
