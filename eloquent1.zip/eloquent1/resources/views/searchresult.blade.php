<table style="width:100%" border="1px">
	<tr>
	<th>id</th>
	<th>email</th>
	<th>class</th>
	</tr>

	@php
	foreach($resultsets as $result){
		echo '<tr>';
		echo '<td>'.$result->id.'</td>';
		echo '<td>'.$result->email.'</td>';
		echo '<td>'.$result->class.'</td>';
		echo '</tr>';
	}
	@endphp
</table>