<html>
	<body>

		<form action="searchresult" method="get">
		ID: <input type="text" name="id"><br>
		E-mail: <input type="text" name="email"><br>
		Class: <input type="text" name="class"><br>
		<input type="submit">
		</form>

	</body>
</html>