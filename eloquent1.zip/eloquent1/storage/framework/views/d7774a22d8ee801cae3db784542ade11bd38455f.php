<html>
	<body>

		<form action="searchresult" method="get">
		ID: <input type="text" name="id"><br>
		E-mail: <input type="text" name="email"><br>
		Class: <input type="text" name="class"><br>
		<input type="submit">
		</form>

	</body>
</html><?php /**PATH C:\Users\kien.nm173206\eloquent1\resources\views/search.blade.php ENDPATH**/ ?>