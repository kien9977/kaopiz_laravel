<table style="width:100%" border="1px">
	<tr>
	<th>id</th>
	<th>Name</th>
	<th>phone</th>
	<th>rolename</th>
	</tr>

	@php
	foreach($resultsets as $result){
		echo '<tr>';
		echo '<td>'.$result->id.'</td>';
		echo '<td>'.$result->first_name.' '.$result->last_name.'</td>';
		echo '<td>'.$result->number.'</td>';
		echo '<td>'.$result->name.'</td>';
		echo '</tr>';
	}
	@endphp
</table>