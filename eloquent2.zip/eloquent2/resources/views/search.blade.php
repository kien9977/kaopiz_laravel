<html>
	<body>

		<form action="searchresult" method="get">
		ID: <input type="text" name="id"><br>
		Phone: <input type="text" name="phone"><br>
		Rolename: <input type="text" name="rolename"><br>
		<input type="submit">
		</form>

	</body>
</html>