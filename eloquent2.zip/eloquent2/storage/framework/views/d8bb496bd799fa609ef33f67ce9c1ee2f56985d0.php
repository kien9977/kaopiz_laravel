<html>
	<body>

		<form action="searchresult" method="get">
		ID: <input type="text" name="id"><br>
		Phone: <input type="text" name="phone"><br>
		Rolename: <input type="text" name="rolename"><br>
		<input type="submit">
		</form>

	</body>
</html><?php /**PATH C:\Users\kien.nm173206\eloquent2\resources\views/search.blade.php ENDPATH**/ ?>