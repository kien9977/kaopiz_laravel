<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class phone extends Model
{
    //

    protected $table = 'phones';

    public function username(){
    	return $this->belongsTo('App\username', 'user_id'); //, 'user_id', 'id'
    }
}
