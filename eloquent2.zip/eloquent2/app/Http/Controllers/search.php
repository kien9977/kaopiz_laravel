<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class search extends Controller
{
    //
    public function search(Request $request){
		if($request["id"] == "" && $request["phone"] == "" && $request["rolename"] == ""){
    		$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->get();
    	}
    	else{ //find($request["id"])
    		if($request["id"] == "" && $request["rolename"] == ""){
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('phones.number','like','%'.$request["phone"].'%')
    						->get();
    		}
    		elseif($request["id"] == "" && $request["phone"] == ""){
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('roles.name','like','%'.$request["rolename"].'%')
    						->get();
    		}
    		elseif($request["phone"] == "" && $request["rolename"] == ""){
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('username.id','like','%'.$request["id"].'%')
    						->get();
    		}
    		elseif($request["id"] == ""){
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('phones.number','like','%'.$request["phone"].'%')
    						->where('roles.name','like','%'.$request["rolename"].'%')
    						->get();
    		}
    		elseif($request["phone"] == ""){
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('username.id','like','%'.$request["id"].'%')
    						->where('roles.name','like','%'.$request["rolename"].'%')
    						->get();
    		}
    		elseif($request["rolename"] == ""){
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('username.id','like','%'.$request["id"].'%')
    						->where('phones.number','like','%'.$request["phone"].'%')
    						->get();
    		}
    		else{
    			$resultsets = DB::table('username')
    						->join('phones','username.id','=','phones.user_id')
    						->join('role_name','username.id','=','role_name.user_id')
    						->join('roles','role_name.role_id','=','roles.id')
    						->where('username.id','like','%'.$request["id"].'%')
    						->where('phones.number','like','%'.$request["phone"].'%')
    						->where('roles.name','like','%'.$request["rolename"].'%')
    						->get();
    		}
    	}
    	
     	return view('searchresult', compact(['resultsets']));
     	// return $resultsets;
    }

}
