<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class rolename extends Model
{
    //
    protected $table = 'rolename';
}
