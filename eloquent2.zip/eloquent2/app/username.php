<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class username extends Model
{
    //
    protected $table = 'username';

    public function phone(){
    	return $this->hasOne('App\phone', 'user_id'); //->select('number')  , 'user_id', 'id'
    }
}
