<!DOCTYPE html>
<html lang="en">
	<head>
	    <meta charset=UTF-8>
	    <title>@yield('title')</title>
	    @section('style')
	    @show
	    @section('declare')
	    @show
	</head>
	<body>
	    @section('navbar')
	    @show

	    <div class="container" style="margin-top:30px">
			<div class="row">
	    		<div class="col-sm-4">
	    			@include('left')
	    		</div>
	    		<div class="col-sm-8">
	    			@include('right')
	    		</div>
	    	</div>
		</div>
	</body>

	@include('footer')
</html>