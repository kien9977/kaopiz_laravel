<!DOCTYPE html>
<html lang="en">
	<head>
	    <meta charset=UTF-8>
	    <title><?php echo $__env->yieldContent('title'); ?></title>
	    <?php $__env->startSection('style'); ?>
	    <?php echo $__env->yieldSection(); ?>
	    <?php $__env->startSection('declare'); ?>
	    <?php echo $__env->yieldSection(); ?>
	</head>
	<body>
	    <?php $__env->startSection('navbar'); ?>
	    <?php echo $__env->yieldSection(); ?>

	    <div class="container" style="margin-top:30px">
			<div class="row">
	    		<div class="col-sm-4">
	    			<?php echo $__env->make('left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    		</div>
	    		<div class="col-sm-8">
	    			<?php echo $__env->make('right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	    		</div>
	    	</div>
		</div>
	</body>

	<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</html><?php /**PATH C:\Users\kien.nm173206\viewblade\resources\views/homechild.blade.php ENDPATH**/ ?>