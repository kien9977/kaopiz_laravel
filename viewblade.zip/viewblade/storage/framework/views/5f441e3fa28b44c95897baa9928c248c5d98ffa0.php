<div class="jumbotron text-center" style="margin-bottom:0">
  <p>Footer</p>
</div><?php /**PATH C:\Users\kien.nm173206\viewblade\resources\views/footer.blade.php ENDPATH**/ ?>