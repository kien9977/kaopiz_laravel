

<?php $__env->startSection('title', 'Bootstrap 4 Website Example'); ?>

<?php $__env->startSection('declare'); ?>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<style>
    .fakeimg {
        height: 200px;
        background: #aaa;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('navbar'); ?>
<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">    
        <?php for($i = 0; $i < 3; $i++): ?>
            <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
              </li>
        <?php endfor; ?>  
    </ul>
  </div>  
</nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('homechild', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kien.nm173206\viewblade\resources\views/home.blade.php ENDPATH**/ ?>