<table style="width:100%" border="1px">
	<tr>
	<th>id</th>
	<th>title</th>
	<th>content</th>
	<th>Create at</th>
	<th>Update at</th>
	<th>Action</th>
	</tr>

	<?php
	foreach($posts as $post){
		echo '<tr>';
		echo '<td>'.$post->id.'</td>';
		echo '<td>'.$post->title.'</td>';
		echo '<td>'.$post->url.'</td>';
		echo '<td>'.$post->created_at.'</td>';
		echo '<td>'.$post->updated_at.'</td>';
		echo '<td><center><a href = "/admin/detail/?postid='.$post->id.'">Detail</a> <a href = "/admin/editposts/?postid='.$post->id.'">Edit</a> <a href="/admin/deleteposts/?postid='.$post->id.'">Delete</a></center></td>';
		echo '</tr>';
	}
	?>
</table><?php /**PATH C:\Users\kien.nm173206\blogging\resources\views/listposts.blade.php ENDPATH**/ ?>