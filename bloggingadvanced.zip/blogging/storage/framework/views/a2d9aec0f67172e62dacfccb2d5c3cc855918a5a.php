<html>
	<head>
		<title>Xem bài viêt</title>
	</head>

	<body>
		<h1><?php echo $posts[0]->title; ?></h1>
		</br>
		<h2>Lúc: <?php echo $posts[0]->updated_at; ?></h2>
		</br>
		<h2><?php echo $posts[0]->content; ?></h2>
		</br>

		<h2>Các bình luận</h2>
		

			<?php
			foreach($comments as $comment){
				echo $comment->updated_at.": ".$comment->content.'</br>';
				echo '----------------------------------</br>';
			}
			?>
	</body>
</html><?php /**PATH C:\Users\kien.nm173206\blogging\resources\views/postview.blade.php ENDPATH**/ ?>