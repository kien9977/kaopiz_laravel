<html>
	<head>
		<title>Trang admin </title>
	</head>
	<body>
		<h1>Trang admin</h1>
		<a href = "/admin/addposts">Thêm bài viêt</a>
		<a href = "/admin/listposts">Liệt kê bài viêt</a>
		<a href = "/admin/logout">Đăng xuất</a>

	</body>
</html><?php /**PATH C:\Users\kien.nm173206\blogging\resources\views/admin.blade.php ENDPATH**/ ?>