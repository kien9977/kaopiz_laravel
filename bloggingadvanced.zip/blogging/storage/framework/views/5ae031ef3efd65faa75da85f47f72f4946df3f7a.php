<html>
	<head>
		<title>Xem bài viêt</title>
	</head>

	<body>
		<form method = 'POST' action='<?php echo e(url('admin/handle-edit')); ?>' role='form'>
			<?php echo e(csrf_field()); ?>

			<h1>Thông tin bài viết</h1>
			</br>
			<a href="/admin/deleteposts/?postid=<?php echo $posts[0]->id; ?>">Xóa</a>
			<h2>ID bài viết: </h2>
			<input type="text" name="postid" id="postid" value="<?php echo $posts[0]->id; ?>" readonly>
			</br>
			<h2>Tiêu đề bài viết: </h2>
			<input type="text" name="title" id="title" value="<?php echo $posts[0]->title; ?>">
			</br>
			<h2>Nội dung bài viết: </h2>
			<textarea name="content" id="content" rows="10" cols="30"><?php echo $posts[0]->content; ?></textarea>
			</br>
			<h2>Thời gian tạo: </h2>
			<input type="text" value="<?php echo $posts[0]->created_at; ?>" disabled>
			</br>
			<h2>Lần sửa cuối: </h2>
			<input type="text" value="<?php echo $posts[0]->updated_at; ?>" disabled>
			</br>
			<input type="submit" value="Submit">
		</form>
	</body>
</html><?php /**PATH C:\Users\kien.nm173206\blogging\resources\views/editposts.blade.php ENDPATH**/ ?>