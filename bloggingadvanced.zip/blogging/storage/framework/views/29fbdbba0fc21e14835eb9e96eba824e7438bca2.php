<!DOCTYPE html>
<html>
<body>

<title>Signup</title>

<h2>Signup</h2>

<form method="POST" action="<?php echo e(url('admin/signup')); ?>" role="form">
	<?php echo e(csrf_field()); ?>

	<label for="username">Username:</label><br>
	<input type="text" id="username" name="username" value=""><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password" value=""><br><br>
	<input type="submit" value="Submit">
</form> 
<a href = "/admin/signup">Đăng ký</a>

</body>
</html>
<?php /**PATH C:\Users\kien.nm173206\blogging\resources\views/signup.blade.php ENDPATH**/ ?>