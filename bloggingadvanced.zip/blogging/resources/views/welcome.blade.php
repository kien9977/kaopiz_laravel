<html>
    <head>
        <title>Blog mới</title>
    </head>

    <body>
        <h1>Tin sốt dẻo</h1>
        @php
            foreach($posts as $post){
                echo 'Bài: <a href="/post/?postid='.$post->id.'"<b>'.$post->title.'</b></a></t>';
                echo 'Lúc: '.$post->updated_at;
                echo '</br>';
            }
        @endphp
    </body>
</html>