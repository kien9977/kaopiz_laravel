<!DOCTYPE html>
<html>
<body>

<title>Signup</title>

<h2>Signup</h2>

<form method="POST" action="{{ url('admin/signup') }}" role="form">
	{{ csrf_field()}}
	<label for="username">Username:</label><br>
	<input type="text" id="username" name="username" value=""><br>
	<label for="email">Email:</label><br>
	<input type="text" id="email" name="email" value=""><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password" value=""><br><br>
	<input type="submit" value="Submit">
</form> 
<a href = "/admin/login">Đăng nhập</a>

</body>
</html>
