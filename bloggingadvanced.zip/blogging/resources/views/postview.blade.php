<html>
	<head>
		<title>Xem bài viêt</title>
	</head>

	<body>
		<h1>@php echo $posts[0]->title; @endphp</h1>
		</br>
		<h2>Lúc: @php echo $posts[0]->updated_at; @endphp</h2>
		</br>
		<h2>@php echo $posts[0]->content; @endphp</h2>
		</br>

		<h2>Các bình luận</h2>
		

			@php
			foreach($comments as $comment){
				echo $comment->updated_at.": ".$comment->content.'</br>';
				echo '----------------------------------</br>';
			}
			@endphp
	</body>
</html>