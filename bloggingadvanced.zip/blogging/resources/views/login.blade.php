@if (session('status'))
<ul>
<li class="text-danger"> {{ session('status') }}</li>
</ul>
@endif

<!DOCTYPE html>
<html>
<body>

<title>Login</title>

<h2>Login</h2>

<form method="POST" action="{{ url('admin/login') }}" role="form">
	{{ csrf_field()}}
	<label for="username">Username:</label><br>
	<input type="text" id="username" name="username" value=""><br>
	<label for="password">Password:</label><br>
	<input type="password" id="password" name="password" value=""><br><br>
	<input type="submit" value="Submit">
</form> 
<a href = "/admin/signup">Đăng ký</a>

</body>
</html>
