<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;


class post extends Controller
{
    //
    public function post(Request $request){
    	if(isset($request["postid"])){
			$count = DB::table('posts')->where('id','=',$request["postid"])->count();
			if($count != 0){
				$posts =  DB::table('posts')->where('id','=',$request["postid"])->get();
	            $comments = DB::table('comments')->where('post_id','=',$request["postid"])->get();
				return view('postview', compact(['posts', 'comments']));
			}
			return view('notfoundposts');
		}
		return view('notfoundposts');
    }
    
}
