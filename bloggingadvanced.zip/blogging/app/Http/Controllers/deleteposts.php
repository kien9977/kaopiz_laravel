<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class deleteposts extends Controller
{
    //
    public function deleteposts(Request $request){
    	if(isset($request["postid"])){
    		$count = DB::table('posts')->where('id','=',$request["postid"])->count();
    		if($count != 0){
    			$posts =  DB::table('posts')->where('id','=',$request["postid"])->delete();
    			$posts =  DB::table('comments')->where('post_id','=',$request["postid"])->delete();
    			return redirect()->back();
    		}
    		return view('notfoundposts');
    	}
    	return view('notfoundposts');
    }
}
