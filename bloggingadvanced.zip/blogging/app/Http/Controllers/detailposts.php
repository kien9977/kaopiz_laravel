<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class detailposts extends Controller
{
    //
    public function detailposts(Request $request){
    	if(isset($request["postid"])){
    		$count = DB::table('posts')->where('id','=',$request["postid"])->count();
    		if($count != 0){
    			$posts =  DB::table('posts')->where('id','=',$request["postid"])->get();
                $comments = DB::table('comments')->where('post_id','=',$request["postid"])->get();
    			return view('detailposts', compact(['posts', 'comments']));
    		}
    		return view('notfoundposts');
    	}
    	return view('notfoundposts');
    }
}
