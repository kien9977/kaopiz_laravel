<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Auth;
use App\User;
use Hash;

class signup extends Controller
{
    //
    public function getsignup()
    {
        if (Auth::check()) {
            // nếu đã nhập thàng công thì 
            return redirect('admin');
        } else {
            return view('signup');
        }

    }

    /**
     * @param LoginRequest $request
     * @return RedirectResponse
     */
    public function postsignup(Request $request)
    {
        if($request->is('admin/*')){
			$data = $request->toArray();

    		$username = $data["username"];
    		$email = $data["email"];
    		$password = $data["password"];
    		DB::table('users')->insert(['name' => $username, 'email' => $email, 'email_verified_at' => now(), 'password' => Hash::make($password), 'created_at' => now(), 'updated_at' => now()]);
    		return view('successupdate');
	    }
	    return view('invalidrequest');
    }
}
