<?php

Route::Get('/', functon(){
	return view( view: 'welcome');
});

Route::Get('/hello', functon(){
	return view( view: 'welcome');
});

