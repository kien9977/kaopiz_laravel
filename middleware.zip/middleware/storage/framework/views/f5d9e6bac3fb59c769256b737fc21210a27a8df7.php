<!DOCTYPE html>
<html>
<body>

<title>Login</title>

<h2>Login</h2>

<form action="/action_page.php">
  <label for="fname">Username:</label><br>
  <input type="text" id="username" name="username" value=""><br>
  <label for="lname">Password:</label><br>
  <input type="password" id="password" name="password" value=""><br><br>
  <input type="submit" value="Submit">
</form> 

</body>
</html>
<?php /**PATH C:\Users\kien.nm173206\middleware\resources\views/login.blade.php ENDPATH**/ ?>