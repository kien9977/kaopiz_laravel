<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class editposts extends Controller
{
    //
    public function editposts(Request $request){
    	if(isset($request["postid"])){
    		$count = DB::table('posts')->where('id','=',$request["postid"])->count();
    		if($count != 0){
    			$posts =  DB::table('posts')->where('id','=',$request["postid"])->get();
    			return view('editposts', compact(['posts']));
    		}
    		return view('notfoundposts');
    	}
    	return view('notfoundposts');
    }

    public function postmakechange(Request $request){
    	if($request->is('admin/*')){
    		$data = $request->toArray();
    		$count = DB::table('posts')->where('id','=',$data["postid"])->count();
	    	if($count != 0){
	    		$title = $data["title"];
	    		$content = $data["content"];
	    		DB::table('posts')->where('id','=',$data["postid"])->Update(['title' => $title, 'content' => $content, 'updated_at' => now()]);
	    		return view('successupdate');
	    	}
	    	return view('notfoundposts');
	    }
	    return view('invalidrequest');
    }
}