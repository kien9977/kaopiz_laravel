<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class listposts extends Controller
{
    //
    public function listposts(){
		$posts = DB::table('posts')->get();
	    return view('listposts', compact(['posts']));
	}
}
