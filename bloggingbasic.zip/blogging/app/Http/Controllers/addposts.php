<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;

class addposts extends Controller
{
    //
    public function addposts(Request $request){
    	if($request->is('admin/*')){
			$data = $request->toArray();

    		$title = $data["title"];
    		$url = $data["url"];
    		$content = $data["content"];
    		DB::table('posts')->insert(['title' => $title, 'content' => $content, 'url' => $url, 'status' => 0, 'created_at' => now(), 'updated_at' => now()]);
    		return view('successupdate');
	    }
	    return view('invalidrequest');
    }
}
