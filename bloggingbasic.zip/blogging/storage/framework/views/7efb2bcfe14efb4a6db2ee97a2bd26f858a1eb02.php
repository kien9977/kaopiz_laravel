<html>
	<head>
		<title>Xem bài viêt</title>
	</head>

	<body>
		<h1>Thông tin bài viết</h1>
		</br>
		<a href = "/admin/editposts/?postid=<?php echo $posts[0]->id; ?>">Sửa</a>
		<a href="/admin/deleteposts/?postid=<?php echo $posts[0]->id; ?>">Xóa</a>
		<h2>Tiêu đề bài viết: </h2>
		<input type="text" value="<?php echo $posts[0]->title; ?>" disabled>
		</br>
		<h2>Nội dung bài viết: </h2>
		<textarea name="message" rows="10" cols="30" disabled><?php echo $posts[0]->content; ?></textarea>
		</br>
		<h2>Thời gian tạo: </h2>
		<input type="text" value="<?php echo $posts[0]->created_at; ?>" disabled>
		</br>
		<h2>Lần sửa cuối: </h2>
		<input type="text" value="<?php echo $posts[0]->updated_at; ?>" disabled>
		</br>

		<h2>Các bình luận</h2>
		<table style="width:100%" border="1px">
			<tr>
			<th>content</th>
			<th>Create at</th>
			<th>Update at</th>
			</tr>

			<?php
			foreach($comments as $comment){
				echo '<tr>';
				echo '<td>'.$comment->content.'</td>';
				echo '<td>'.$comment->created_at.'</td>';
				echo '<td>'.$comment->updated_at.'</td>';
				echo '</tr>';
			}
			?>
		</table>
	</body>
</html><?php /**PATH C:\Users\kien.nm173206\blogging\resources\views/detailposts.blade.php ENDPATH**/ ?>