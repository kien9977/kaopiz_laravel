<html>
	<head>
		<title>Xem bài viêt</title>
	</head>

	<body>
		<form method = 'POST' action='{{ url('admin/handle-edit') }}' role='form'>
			{{ csrf_field()}}
			<h1>Thông tin bài viết</h1>
			</br>
			<a href="/admin/deleteposts/?postid=@php echo $posts[0]->id; @endphp">Xóa</a>
			<h2>ID bài viết: </h2>
			<input type="text" name="postid" id="postid" value="@php echo $posts[0]->id; @endphp" readonly>
			</br>
			<h2>Tiêu đề bài viết: </h2>
			<input type="text" name="title" id="title" value="@php echo $posts[0]->title; @endphp">
			</br>
			<h2>Nội dung bài viết: </h2>
			<textarea name="content" id="content" rows="10" cols="30">@php echo $posts[0]->content; @endphp</textarea>
			</br>
			<h2>Thời gian tạo: </h2>
			<input type="text" value="@php echo $posts[0]->created_at; @endphp" disabled>
			</br>
			<h2>Lần sửa cuối: </h2>
			<input type="text" value="@php echo $posts[0]->updated_at; @endphp" disabled>
			</br>
			<input type="submit" value="Submit">
		</form>
	</body>
</html>