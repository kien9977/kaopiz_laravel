<html>
	<head>
		<title>Thêm bài viêt</title>
	</head>

	<body>
		<form method = 'POST' action='{{ url('admin/handle-add') }}' role='form'>
			{{ csrf_field() }}
			<h1>Thêm bài viết</h1>
			</br>
			
			<h2>Tiêu đề bài viết: </h2>
			<input type="text" name="title" id="title" value="">
			</br>
			<h2>URL bài viết: </h2>
			<input type="text" name="url" id="url" value="">
			</br>
			<h2>Nội dung bài viết: </h2>
			<textarea name="content" id="content" rows="10" cols="30"></textarea>
			</br>
			<input type="submit" value="Submit">
		</form>
	</body>
</html>